from board import Board
import numpy as np
from search import SearchProblem, ucs
import util


class BlokusFillProblem(SearchProblem):
    """
    A one-player Blokus game as a search problem.
    This problem is implemented for you. You should NOT change it!
    """

    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.expanded = 0

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        """
        state: Search state
        Returns True if and only if the state is a valid goal state
        """
        return not any(state.pieces[0])

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, 1) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        return len(actions)


#####################################################
# This portion is incomplete.  Time to write code!  #
#####################################################
class BlokusCornersProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        self.expanded = 0
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.targets = [(0, 0), (board_h - 1, 0), (board_h - 1, board_w - 1), (0, board_w - 1)]

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        board_matrix = state.state
        # Check if the corners are not empty (player 0 has a tile there)
        return board_matrix[0, 0] == 0 and board_matrix[-1, 0] == 0 and\
            board_matrix[0, -1] == 0 and board_matrix[-1, -1] == 0

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        sum_of_tile_sizes = 0
        for action in actions:
            sum_of_tile_sizes += action.piece.get_num_tiles()
        return sum_of_tile_sizes


def blokus_corners_heuristic(state, problem):
    """
    Your heuristic for the BlokusCornersProblem goes here.

    This heuristic must be consistent to ensure correctness.  First, try to come up
    with an admissible heuristic; almost all admissible heuristics will be consistent
    as well.

    If using A* ever finds a solution that is worse uniform cost search finds,
    your heuristic is *not* consistent, and probably not admissible!  On the other hand,
    inadmissible or inconsistent heuristics may find optimal solutions, so be careful.
    """             
    board = state.state
    corners = problem.targets  

    # the minimum piece avialble, always smaller the the sulotion
    min_piece_size = get_min_unused_piece_size(state)
    
    # the numbr of uncovered corners, always smaller the the sulotion
    uncovered_corners = get_uncovered_targets(board, corners)

    # one axis distance, always smaller the the sulotion
    max_corner_distance = get_max_distance_between_corner_and_possible_tile(state, uncovered_corners)
    
    # max between the two     
    return max(min_piece_size, len(uncovered_corners)+max_corner_distance)    

def get_min_unused_piece_size(state):
    """This function returns the size of the smallest unused piece for any player in the current game state."""
    pieces = []
    
    for player_piece in state.piece_list:
        for index, piece in enumerate(player_piece):
            if piece == True:
                pieces.append(state.piece_list.get_piece(index).get_num_tiles())
    
    return min(pieces, default=0)
                    
def get_uncovered_targets(board, targets):
    """This function returns a list of target coordinates that are not covered by any player's tiles on the board."""
    uncovered_targets = []
    
    for target in targets:
        if board[target] != 0:
            uncovered_targets.append(target)
    
    return uncovered_targets
            
def get_max_distance_between_corner_and_possible_tile(state, targets):
    """This function calculates the maximum distance between any legal tile and the nearest corner of the board. The distance is defined as the maximum of the absolute differences in x and y coordinates."""
    legal_tiles = []

    for y in range(state.board_h):
        for x in range(state.board_w):
            if state.check_tile_legal(0, x, y):
                legal_tiles.append((y, x))

    min_target_dist = float('inf')
    targets_distances = []
    
    for target in targets:
        for tile in legal_tiles:
            distance = max(abs(tile[0]-target[0]), abs(tile[1]-target[1]))
            if distance < min_target_dist:
                min_target_dist = distance
        targets_distances.append(min_target_dist)
        min_target_dist = 0
    
    return max(targets_distances, default=0)    

class BlokusCoverProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0), targets=[(0, 0)]):
        self.targets = targets.copy()
        self.expanded = 0
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        board_matrix = state.state
        is_filled = True
        for target in self.targets:
            is_filled = is_filled and (board_matrix[target] == 0)
        return is_filled

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        sum_of_tile_sizes = 0
        for action in actions:
            sum_of_tile_sizes += action.piece.get_num_tiles()
        return sum_of_tile_sizes
    
    def get_targets(self):
        return self.targets


def blokus_cover_heuristic(state, problem):
    board = state.state
    targets = problem.targets  

    # the minimum piece avialble, always smaller the the sulotion
    min_piece_size = get_min_unused_piece_size(state)

    # the numbr of uncovered targets, always smaller the the sulotion
    uncovered_targets = get_uncovered_targets(board, targets)
    
    # one axis distance, always smaller the the sulotion  
    max_target_distance = get_max_distance_between_corner_and_possible_tile(state, uncovered_targets)
    
    # max between the three       
    # the plus is because the distance is from uncoverd tile to the target so we can add the target   
    return max(max_target_distance + 1, len(uncovered_targets), min_piece_size) 

