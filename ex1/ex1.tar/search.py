"""
In search.py, you will implement generic search algorithms
"""

import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        util.raiseNotDefined()

    def is_goal_state(self, state):
        """
        state: Search state

        Returns True if and only if the state is a valid goal state
        """
        util.raiseNotDefined()

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        util.raiseNotDefined()

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        util.raiseNotDefined()


class Node:
    def __init__(self, state, parent, cost, action):
        self.parent = parent
        self.cost = cost
        self.state = state
        self.action = action

    def get_state(self):
        return self.state

    def get_cost(self):
        return self.cost

    def get_full_path(self):
        path = []
        current = self
        while current.action is not None:
            path.append(current.action)
            current = current.parent
        return path[::-1]


def generic_search(problem, fringe, check_only_after_pop=False):
    """
    Generic search function.
    uses the given fringe, and based on the check_only_after_pop flag
    chacks if a state is a goal state before/after the entrance to the fringe
    (in dfs/bfs we can check before and in ucs and astar we need to check only after we pop)
    """
    # visited holds only states object and not board objects
    visited = set()
    # Starting state and empty path
    current_state = problem.get_start_state()
    if problem.is_goal_state(current_state):
        return []
    current_node = Node(current_state, None, 0, None)
    fringe.push(current_node)

    while not fringe.isEmpty():
        current_node = fringe.pop()
        current_state = current_node.get_state()
        if current_state in visited:
            continue

        if check_only_after_pop:
            if problem.is_goal_state(current_state):
                return current_node.get_full_path()

        successors = problem.get_successors(current_state)
        for successor_triplet in successors:
            suc_state, action, cost = successor_triplet
            suc_cost = current_node.get_cost() + cost
            successor_node = Node(suc_state, current_node, suc_cost, action)
            if not check_only_after_pop:
                if problem.is_goal_state(suc_state):
                    return successor_node.get_full_path()
            fringe.push(successor_node)
        visited.add(current_state)
    # No solution
    return None


def depth_first_search(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches
    the goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """
    return generic_search(problem, util.Stack(), False)


def breadth_first_search(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    return generic_search(problem, util.Queue(), False)


def uniform_cost_search(problem):
    """
    Search the node of least total cost first.
    """
    return generic_search(problem, util.PriorityQueueWithFunction(priorityFunction=priority_cost_function), True)


def null_heuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def a_star_search(problem, heuristic=null_heuristic):
    """
    Search the node that has the lowest combined cost and heuristic first.
    """
    cost_function = heuristic_cost_function(heuristic=heuristic, problem=problem)
    fringe = util.PriorityQueueWithFunction(priorityFunction=cost_function)
    return generic_search(problem, fringe, True)


def priority_cost_function(node):
    return node.get_cost()


def heuristic_cost_function(problem, heuristic):
    def priority_cost(node):
        return node.get_cost() + heuristic(node.get_state(), problem)
    return priority_cost


# Abbreviations
bfs = breadth_first_search
dfs = depth_first_search
astar = a_star_search
ucs = uniform_cost_search
